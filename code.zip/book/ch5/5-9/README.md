根据论文《A Discriminative Feature Learning Approach for Deep Face Recognition》实现了一个简单版本的center loss cpu版。

详细内容欢迎阅读知乎专栏——《无痛的机器学习》：https://zhuanlan.zhihu.com/p/23444100

实验了论文中提出的MNist数据库，和论文结果大体一致。

基本的文件都在，大家按需放在Caffe中该放的位置，应该就可以跑起来了。

predict.py用于预测数据的2维representation

visualize.py用于把这些数据画出来
