import numpy as np

def relu(x):
	return x if x > 0 else 0

