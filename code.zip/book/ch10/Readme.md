### 10 应用——图像生成

* 10-1：参见https://link.zhihu.com/?target=https%3A//github.com/cdoersch/vae_tutorial
* 10-2.py：KL散度与JS散度
* 10-2：参见https://github.com/jacobgil/keras-dcgan
* 10-3.py：互信息展示
* 10-3：参见https://github.com/openai/InfoGAN
* 10-4：参见https://github.com/igul222/improved_wgan_training