### 9 应用——图像的语义分割

* 9.1: IoU实现
* 9.2: 无向图计算联合概率和边际概率
代码详见：https://github.com/torrvision/crfasrnn
