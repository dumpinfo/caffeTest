### 8.3 SGD的变种算法

* 8-1.py：梯度下降法介绍

* 8-2.py：Momentum，Nesterov算法介绍

* 8-3.py：SGD变种算法介绍

* 8-4.py：L1正则的优化算法介绍

* 8-5.py：（未完）Fool CNN算法

* 8-6.py：优化路径可视化

* 8-7.py：模型过拟合

  ​